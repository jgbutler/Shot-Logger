-- Adminer 3.7.1 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '-05:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE TABLE `sl_ImdbMap` (
  `ImdbMapID` int(11) NOT NULL AUTO_INCREMENT,
  `IMDbID` varchar(20) DEFAULT NULL,
  `ImdbTitle` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`ImdbMapID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


CREATE TABLE `sl_ShotData` (
  `shotID` int(11) NOT NULL AUTO_INCREMENT,
  `ShotNumber` int(11) DEFAULT NULL,
  `g_id` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(128) DEFAULT NULL,
  `sl_directory` varchar(256) DEFAULT NULL,
  `g_idOfThumbnail` int(11) DEFAULT '0',
  `g_parentid` int(11) DEFAULT '0',
  `slTitleID` int(11) DEFAULT NULL,
  `IMDbID` varchar(20) DEFAULT NULL,
  `TimeCode` int(11) DEFAULT '0',
  `ShotLength` int(11) DEFAULT '0',
  `ShotScale` int(2) DEFAULT NULL,
  `ShotHeight` int(6) DEFAULT NULL,
  `ShotWidth` int(6) DEFAULT NULL,
  `ShotRatioToOne` decimal(3,2) DEFAULT NULL,
  `CameraMovement` varchar(20) DEFAULT NULL,
  `Comments` text,
  `Keywords` varchar(255) DEFAULT '0',
  `SubmittedBy` int(11) DEFAULT '0',
  `DateSubmitted` int(11) DEFAULT NULL,
  `LastModified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`shotID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


CREATE TABLE `sl_Statistics` (
  `statsID` int(11) NOT NULL AUTO_INCREMENT,
  `TitlesCount` int(11) DEFAULT '0',
  `IMDBTitlesCount` int(11) DEFAULT '0',
  `ShotsSum` int(11) DEFAULT '0',
  `ShotsCount` int(11) DEFAULT '0',
  `CPMMean` decimal(11,2) DEFAULT '0.00',
  `CPMMedian` decimal(11,2) DEFAULT '0.00',
  `ShotsSumMean` decimal(11,2) DEFAULT '0.00',
  `ShotsCountMean` decimal(11,2) DEFAULT '0.00',
  `ShotScale` varchar(20) DEFAULT NULL,
  `CameraMovement` varchar(20) DEFAULT NULL,
  `Comments` text,
  `LastUpdated` int(11) DEFAULT NULL,
  PRIMARY KEY (`statsID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


CREATE TABLE `sl_Title2` (
  `slTitleID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(128) DEFAULT NULL,
  `sl_directory` varchar(256) DEFAULT NULL,
  `IMDbID` varchar(20) DEFAULT NULL,
  `EpisodeDate` date DEFAULT NULL,
  `MovieDate` varchar(10) DEFAULT NULL,
  `Comments` text,
  `Keywords` varchar(255) DEFAULT NULL,
  `Length` int(11) DEFAULT '0',
  `ShotTotal` int(11) DEFAULT '0',
  `CPM` decimal(10,2) DEFAULT '0.00',
  `AverageShotLength` decimal(10,2) DEFAULT '0.00',
  `MedianShotLength` decimal(10,1) DEFAULT NULL,
  `MSL_ASL` decimal(10,2) DEFAULT NULL,
  `Mode` varchar(128) DEFAULT NULL,
  `MinimumMode` int(4) DEFAULT NULL,
  `MaximumMode` int(4) DEFAULT NULL,
  `MinimumSL` int(4) DEFAULT '0',
  `MaximumSL` int(11) DEFAULT '0',
  `Range` int(11) DEFAULT '0',
  `StandardDeviation` decimal(10,2) DEFAULT '0.00',
  `CV` decimal(10,2) DEFAULT NULL,
  `Skewness` decimal(10,2) DEFAULT NULL,
  `Kurtosis` decimal(10,2) DEFAULT NULL,
  `Q1` decimal(10,2) DEFAULT NULL,
  `Q3` decimal(10,2) DEFAULT NULL,
  `IQR` decimal(10,2) DEFAULT NULL,
  `Variance` decimal(10,2) DEFAULT NULL,
  `DateSubmittedV2` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `LastModified` int(11) DEFAULT '0',
  PRIMARY KEY (`slTitleID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


-- 2015-07-22 16:07:42
